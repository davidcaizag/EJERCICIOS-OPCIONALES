import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel principal;
    private JTextArea txtCodigo;
    private JButton btnComprobar;
    private JTextArea txtPila;

    public Ventana() {
        btnComprobar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    Pila p = new Pila();
                    String codigo = txtCodigo.getText();
                    txtPila.setText("");

                    for (int i = 0; i <= codigo.length() - 1; i++) {
                        char c = codigo.charAt(i);

                        if (c == '(') {
                            p.insertar(String.valueOf(c));
                            JOptionPane.showMessageDialog(null, "Insertado: " + c);
                            txtPila.setText(p.toString());

                            if (c == ')' || c == '}' || c == ']') {
                                if (p.esVacia()) {
                                    JOptionPane.showMessageDialog(null, "Código incorrecto: cierre sin apertura.");
                                    return;
                                }

                            }
                            char apertura = p.extraer().charAt(0);
                            JOptionPane.showMessageDialog(null, "Extraído: " + apertura);
                            txtPila.setText(p.toString());
                            if ((c == ')' && apertura != '(') ||
                                    (c == '}' && apertura != '{') ||
                                    (c == ']' && apertura != '[')) {
                                JOptionPane.showMessageDialog(null, "Código incorrecto: símbolos no coinciden.");
                                return;
                            }
                        }
                    }




                    if (p.esVacia()) {
                        JOptionPane.showMessageDialog(null, "Codigo correcto");
                    } else {
                        JOptionPane.showMessageDialog(null, "Codigo incorrecto");
                    }

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }

            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
