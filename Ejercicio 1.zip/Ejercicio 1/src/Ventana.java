import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Ventana {
    private JPanel principal;
    private JButton btnInsertar;
    private JButton btnExtraer;
    private JTextArea txtListado;
    private JLabel lblEtiqueta;
    private JTextField txtDato;
    private Pila coleccion;

    public Ventana() {
        // Inicializa componentes y lógica de la interfaz
        principal = new JPanel();
        btnInsertar = new JButton("Insertar");
        btnExtraer = new JButton("Extraer");
        txtListado = new JTextArea(10, 20);
        lblEtiqueta = new JLabel("Dato:");
        txtDato = new JTextField(15);

        // Agrega componentes al panel principal
        principal.add(lblEtiqueta);
        principal.add(txtDato);
        principal.add(btnInsertar);
        principal.add(btnExtraer);
        principal.add(txtListado);

        coleccion = new Pila();

        btnInsertar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    coleccion.insertar(txtDato.getText());
                    txtListado.setText(coleccion.toString());
                    txtDato.setText("");
                } catch (IllegalStateException ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        btnExtraer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String eliminado = coleccion.extraer();
                    JOptionPane.showMessageDialog(null, "Se eliminó: " + eliminado);
                    txtListado.setText(coleccion.toString());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "La pila está vacía.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
