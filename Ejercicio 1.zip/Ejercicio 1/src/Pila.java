import java.util.Stack;

public class Pila {
    private Stack<String> coleccion = new Stack<>();
    private static final int LIMITE = 10;

    public Pila() {}

    public void insertar(String dato) {
        if (coleccion.size() >= LIMITE) {
            throw new IllegalStateException("La pila ha alcanzado el límite de 10 elementos.");
        }
        coleccion.push(dato);
    }

    public String extraer() {
        return coleccion.pop();
    }

    public String cima() {
        return coleccion.peek();
    }

    public String toString() {
        StringBuilder lista = new StringBuilder();

        for (int i = coleccion.size() - 1; i >= 0; --i) {
            lista.append(coleccion.get(i)).append("\n");
        }

        return lista.toString();
    }
}

